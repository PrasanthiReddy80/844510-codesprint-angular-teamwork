import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-naviagtion-bar',
  templateUrl: './top-naviagtion-bar.component.html',
  styleUrls: ['./top-naviagtion-bar.component.css']
})
export class TopNaviagtionBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
